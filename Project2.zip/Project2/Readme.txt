db.productdetails.insert([{"product_name":"Watch","price":800,"discount":200},{"product_name":"T-shirt","price":1000,"discount":500}])
db.users.insert({"product_name":"Watch","price":800,"discount":200})

async function dbconnect() {
    var connection = await mongoose.connect(
      "mongodb://127.0.0.1:27017/productdetails"
    );
    return connection;
}

db();

const productschema = new Schema({
  product_name: String,
  price: Number,
  discount: Number,
});

const productModel = mongoose.model("productdetails", productschema);

app.get("/product", async (req, res) => {
  try {
    var result = await productModel.find();
    res.send(result);
  } catch (error) {
    res.send(error.message);
  }
});

app.post("/product", async (req, res) => {
  // console.log(req.body);
  try {
    var record = new userModel(req.body);
    var ans = await record.save();
    res.send("record inserted");
  } catch (error) {
    res.send(error.message);
  }
});