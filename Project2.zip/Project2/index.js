var express = require("express");
var mongoose = require("mongoose");
var mysql = require("mysql");

var app = express();


var db = require("./db.js");


app.use(express.json());
db();

const Schema = mongoose.Schema;
const productsschema = new Schema({
  product_name: String,
  price: Number,
  discount: Number,
});

const productModel = mongoose.model("productdetails", productsschema);

app.get("/product", async (req, res) => {
  try {
    var result = await productModel.find();
    res.send(result);
  } catch (error) {
    res.send(error.message);
  }
});

app.post("/product", async (req, res) => {
  // console.log(req.body);
  try {
    var record = new productModel(req.body);
    var ans = await record.save();
    res.send("record inserted");
  } catch (error) {
    res.send(error.message);
  }
});

app.listen(8000);
